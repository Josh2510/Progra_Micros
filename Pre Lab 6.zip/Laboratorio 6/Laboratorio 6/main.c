/*
 * Laboratorio 6.c
 *
 * Created: 4/24/2026 8:23:15 AM
 * Author : Josue
 */ 

/****************************************/
// Encabezado (Libraries)
#define F_CPU 16000000
#include <avr/io.h>
#include <avr/interrupt.h>
#include "UART/UART.h"

/****************************************/
// Function prototypes

/****************************************/
// Main Function
int main(void)
{
	cli();
	// HABILITAR SALIDAS
	// PORT B INICIALMENTE APAGADOS DE PB0 A PB4
	DDRB	|= ((1 << DDB4) | (1 << DDB3) | (1 << DDB2) | (1 << DDB1) | (1 << DDB0));
	PORTB	&= ~((1 << PORTB4) | (1 << PORTB3) | (1 << PORTB2) | (1 << PORTB1) | (1 << PORTB0));
	// PORTD INICIALMENTE APAGADO DE PD5 A PD7
	DDRD	|= ((1 << DDD7) | (1 << DDD6) | (1 << DDD5));
	PORTD	&= ~((1 << PORTD7) | (1 << PORTD6) | (1 << PORTD5));
	// INICIALIZAR MODULO UART
	init_UART();
	sei();
	
	writeChar('H');
	while (1)
	{
	}
}
/****************************************/
// NON-Interrupt subroutines

/****************************************/
// Interrupt routines
ISR(USART_RX_vect)
{
	uint8_t bufferRX = UDR0;
	writeChar(bufferRX);
	PORTD = (bufferRX << 5);
	PORTB = (bufferRX >> 3);
}