/*
 * PWM1.h
 *
 * Created: 4/17/2026 9:14:23 AM
 *  Author: Josue
 */ 


#ifndef PWM1_H_
#define PWM1_H_


#define no_invertido	0
#define invertido		1
#define fastPWM			0
#define phasePWM		1

void PWM1_init(void);
void UPDATE_Duty_Cycle(uint16_t dutyCicle);

#endif /* PWM1_H_ */