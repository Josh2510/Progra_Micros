/*
 * Laboratorio 5.c
 *
 * Created: 4/16/2026 10:19:40 PM
 * Author : Josue
 */ 
/****************************************/
// Encabezado (Libraries)
#define F_CPU 16000000
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "PWM1/PWM1.h"

/****************************************/
// Function prototypes
void setup();
void ADC_init();

volatile uint16_t servo1 = 0;
/****************************************/
// Main Function
int main(void)
{
	setup();
	while (1)
	{
		UPDATE_Duty_Cycle(800 + ((uint32_t)servo1 * 4000)/1023);
	}
}
/****************************************/
// NON-Interrupt subroutines
void setup()
{
	cli();
	PWM1_init();
	ADC_init();
	sei();
}
void ADC_init()
{
	// HABILITAR ADC CON VOLTAJE EXTERNO Y EN EL ADC0
	ADMUX = 0;
	ADMUX |= (1 << REFS0);
	// HABILITAR ADC, SU INTERRUPCION Y PONER PRESCALER DE 8
	ADCSRA = 0;
	ADCSRA |= (1 << ADEN) | (1<<ADIE)| (1<<ADPS1) | (1<<ADPS0);
	ADCSRA |= (1 << ADSC);
}
/****************************************/
// Interrupt routines
ISR(ADC_vect)
{
	servo1 = ADC;
	ADCSRA |= (1 << ADSC);
}